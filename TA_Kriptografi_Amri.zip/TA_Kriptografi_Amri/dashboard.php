<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Keamanan Komunikasi Bisnis</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body {
            background: linear-gradient(120deg, #6e8efb, #a777e3);
            min-height: 100vh;
            color: #fff;
            font-family: 'Arial', sans-serif;
        }
        .dashboard {
            margin-top: 50px;
            padding: 30px;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.1);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
        }
        .btn-option {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: #fff;
            font-size: 18px;
            transition: all 0.3s ease;
        }
        .btn-option:hover {
            background: rgba(255, 255, 255, 0.4);
            transform: scale(1.05);
        }
        h2 {
            font-weight: bold;
            color: #fff;
        }
        .welcome {
            text-align: center;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="dashboard mx-auto col-md-6 text-center">
            <div class="welcome">
                <h2>Selamat Datang, <?= htmlspecialchars($username); ?>!</h2>
                <p>Pilih opsi berikut untuk melanjutkan:</p>
            </div>
            <div class="d-grid gap-3">
                <a href="encrypt_text.php" class="btn btn-option">🔒 Enkripsi Teks</a>
                <a href="encrypt_file.php" class="btn btn-option">📁 Enkripsi File</a>
                <a href="encrypt_image.php" class="btn btn-option">🖼️ Enkripsi Gambar (Steganografi)</a>
                <a href="logout.php" class="btn btn-option">🚪 Logout</a>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
