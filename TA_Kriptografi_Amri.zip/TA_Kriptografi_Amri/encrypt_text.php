<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $plaintext = $_POST['text'];
    $encryption_key = "encryptionkey123";
    $vigenere_key = "VIGENERE";

    // AES Encryption
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
    $aes_encrypted = openssl_encrypt($plaintext, 'aes-256-cbc', $encryption_key, 0, $iv);

    // Vigenere Encryption
    function vigenere_encrypt($text, $key) {
        $text = strtoupper($text);
        $key = strtoupper($key);
        $encrypted = "";
        $keyIndex = 0;

        foreach (str_split($text) as $char) {
            if (ctype_alpha($char)) {
                $offset = ord($char) + ord($key[$keyIndex]) - 2 * ord('A');
                $encrypted .= chr($offset % 26 + ord('A'));
                $keyIndex = ($keyIndex + 1) % strlen($key);
            } else {
                $encrypted .= $char;
            }
        }

        return $encrypted;
    }

    $super_encrypted = vigenere_encrypt($aes_encrypted, $vigenere_key);
    $encrypted_message = base64_encode($iv) . "::" . base64_encode($super_encrypted);

    $message = "Teks berhasil dienkripsi!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enkripsi Teks - Keamanan Komunikasi Bisnis</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body {
            background: linear-gradient(120deg, #6e8efb, #a777e3);
            min-height: 100vh;
            color: #fff;
            font-family: 'Arial', sans-serif;
        }
        .encrypt-text {
            margin-top: 50px;
            padding: 30px;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.1);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
        }
        .btn-custom {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: #fff;
            font-size: 18px;
            transition: all 0.3s ease;
        }
        .btn-custom:hover {
            background: rgba(255, 255, 255, 0.4);
            transform: scale(1.05);
        }
        h2 {
            font-weight: bold;
            color: #fff;
        }
        .back-btn {
            margin-top: 20px;
        }
        .message {
            font-size: 16px;
            font-weight: bold;
            background: rgba(0, 255, 0, 0.2);
            color: #fff;
            padding: 10px;
            border-radius: 5px;
        }
        textarea {
            resize: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="encrypt-text mx-auto col-md-6 text-center">
            <h2>Enkripsi Teks</h2>
            <p>Masukkan teks yang ingin dienkripsi:</p>

            <?php if (isset($message)): ?>
                <div class="message mb-3">
                    <?= htmlspecialchars($message); ?>
                </div>
                <div class="mb-3">
                    <textarea class="form-control" rows="5" readonly><?= htmlspecialchars($encrypted_message); ?></textarea>
                </div>
            <?php endif; ?>

            <form method="POST" action="encrypt_text.php" class="mt-3">
                <textarea name="text" class="form-control mb-3" rows="5" placeholder="Masukkan teks..." required></textarea>
                <button type="submit" class="btn btn-custom">🔒 Enkripsi Teks</button>
            </form>

            <a href="dashboard.php" class="btn btn-custom back-btn">⬅️ Kembali ke Dashboard</a>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
