<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $file = $_FILES['file']['tmp_name'];
    $encryption_key = "encryptionkey123";

    // Membaca file
    $file_content = file_get_contents($file);
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));

    $ciphertext = openssl_encrypt($file_content, 'aes-256-cbc', $encryption_key, 0, $iv);
    $ciphertext_base64 = base64_encode($iv . $ciphertext); // Gabungkan IV dan cipher dalam base64

    // Menyimpan file terenkripsi
    $output_file = "uploads/encrypted_" . $_FILES['file']['name'];
    file_put_contents($output_file, $ciphertext_base64);

    $message = "File berhasil dienkripsi!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enkripsi File - Keamanan Komunikasi Bisnis</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body {
            background: linear-gradient(120deg, #6e8efb, #a777e3);
            min-height: 100vh;
            color: #fff;
            font-family: 'Arial', sans-serif;
        }
        .encrypt-file {
            margin-top: 50px;
            padding: 30px;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.1);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
        }
        .btn-custom {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: #fff;
            font-size: 18px;
            transition: all 0.3s ease;
        }
        .btn-custom:hover {
            background: rgba(255, 255, 255, 0.4);
            transform: scale(1.05);
        }
        h2 {
            font-weight: bold;
            color: #fff;
        }
        .back-btn {
            margin-top: 20px;
        }
        .message {
            font-size: 16px;
            font-weight: bold;
            background: rgba(0, 255, 0, 0.2);
            color: #fff;
            padding: 10px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="encrypt-file mx-auto col-md-6 text-center">
            <h2>Enkripsi File</h2>
            <p>Pilih file yang ingin dienkripsi:</p>

            <?php if (isset($message)): ?>
                <div class="message mb-3">
                    <?= htmlspecialchars($message); ?>
                </div>
                <a href="<?= $output_file; ?>" class="btn btn-custom" download>⬇️ Unduh File Terenkripsi</a>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data" action="encrypt_file.php" class="mt-3">
                <input type="file" name="file" class="form-control mb-3" required>
                <button type="submit" class="btn btn-custom">🔒 Enkripsi File</button>
            </form>

            <a href="dashboard.php" class="btn btn-custom back-btn">⬅️ Kembali ke Dashboard</a>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
