<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
    $image = $_FILES['image']['tmp_name'];
    $encryption_key = "encryptionkey123";

    // Membaca gambar
    $image_content = file_get_contents($image);

    // Steganografi sederhana: tambahkan header terenkripsi
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
    $encrypted_data = openssl_encrypt($image_content, 'aes-256-cbc', $encryption_key, 0, $iv);
    $encrypted_image = base64_encode($iv . $encrypted_data); // Gabungkan IV dan data terenkripsi

    // Simpan gambar terenkripsi
    $output_image = "uploads/encrypted_" . $_FILES['image']['name'];
    file_put_contents($output_image, $encrypted_image);

    $message = "Gambar berhasil dienkripsi!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enkripsi Gambar - Keamanan Komunikasi Bisnis</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body {
            background: linear-gradient(120deg, #6e8efb, #a777e3);
            min-height: 100vh;
            color: #fff;
            font-family: 'Arial', sans-serif;
        }
        .encrypt-image {
            margin-top: 50px;
            padding: 30px;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.1);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
        }
        .btn-custom {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: #fff;
            font-size: 18px;
            transition: all 0.3s ease;
        }
        .btn-custom:hover {
            background: rgba(255, 255, 255, 0.4);
            transform: scale(1.05);
        }
        h2 {
            font-weight: bold;
            color: #fff;
        }
        .back-btn {
            margin-top: 20px;
        }
        .message {
            font-size: 16px;
            font-weight: bold;
            background: rgba(0, 255, 0, 0.2);
            color: #fff;
            padding: 10px;
            border-radius: 5px;
        }
        .image-preview {
            max-width: 100%;
            max-height: 300px;
            margin: 15px 0;
            border: 2px dashed #fff;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="encrypt-image mx-auto col-md-6 text-center">
            <h2>Enkripsi Gambar</h2>
            <p>Unggah gambar yang ingin dienkripsi:</p>

            <?php if (isset($message)): ?>
                <div class="message mb-3">
                    <?= htmlspecialchars($message); ?>
                </div>
                <a href="<?= $output_image; ?>" class="btn btn-custom" download>⬇️ Unduh Gambar Terenkripsi</a>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data" action="encrypt_image.php" class="mt-3">
                <input type="file" name="image" class="form-control mb-3" accept="image/*" required>
                <button type="submit" class="btn btn-custom">🔒 Enkripsi Gambar</button>
            </form>

            <a href="dashboard.php" class="btn btn-custom back-btn">⬅️ Kembali ke Dashboard</a>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
